using "clang++ main.cpp card.cpp board.cpp player.cpp -o main.out" to build this main.cpp file.
execute it by "./main.out"